// changes janes name

function changeName(){
    document.querySelector("#text").innerHTML = "Reb Hillel Parecher";
}



// removing person from connection requests adding and subtracting numbers
function remove(name){
    var click = document.querySelector(name);
    click.remove();
    var a = document.querySelector("#numbertwo").innerHTML;
    var b = a-1;
    console.log(b);
    document.querySelector("#numbertwo").innerHTML = b;
}
function add(){
    var c = 500
    var d = c+1;
    document.querySelector(".fivehundred").innerHTML = d;
}


